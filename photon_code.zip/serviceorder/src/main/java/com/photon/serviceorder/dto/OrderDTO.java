package com.photon.serviceorder.dto;

import java.time.Instant;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class OrderDTO {

	private Long id;
	
	private Integer productId;
	private String customerName;
	private Instant orderDate;
	

}
