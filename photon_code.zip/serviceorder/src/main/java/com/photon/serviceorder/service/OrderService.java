package com.photon.serviceorder.service;

import org.springframework.http.ResponseEntity;

import com.photon.serviceorder.dto.OrderDTO;

public interface OrderService {
	public ResponseEntity<?> createOrder(OrderDTO order);

}
