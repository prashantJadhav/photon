package com.photon.serviceorder.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.photon.serviceorder.dto.OrderDTO;
import com.photon.serviceorder.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@PostMapping(value="/orders")
	public ResponseEntity<?> createOrder(@RequestBody OrderDTO order)
	{
		return orderService.createOrder(order);
	}
}
