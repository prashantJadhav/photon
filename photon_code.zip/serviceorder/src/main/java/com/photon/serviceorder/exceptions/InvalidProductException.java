package com.photon.serviceorder.exceptions;

public class InvalidProductException extends RuntimeException{
	
	public InvalidProductException(String ex) {
		super(ex);
	}

}
