package com.photon.serviceorder.repositories;
import org.springframework.data.jpa.repository.JpaRepository;


import com.photon.serviceorder.entities.Order;

public interface OrderRepositories extends JpaRepository<Order,Long>{
	

}
