package com.photon.serviceorder.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.photon.serviceorder.dto.APIResponse;
import com.photon.serviceorder.dto.OrderDTO;
import com.photon.serviceorder.entities.Order;
import com.photon.serviceorder.exceptions.InvalidProductException;
import com.photon.serviceorder.repositories.OrderRepositories;

public class OrderSeviceImpl implements OrderService {

	public static Logger log =  LogManager.getLogger(OrderSeviceImpl.class);

	@Autowired
	OrderRepositories orderRepo ;
	
	@Autowired
	RestTemplate restTemplate ;
	
	
	public ResponseEntity<?> createOrder(OrderDTO orderReq){
		
		log.trace("OrderSeviceImpl::createOrder");
		
		//build entiry from DTO
		
		Order order = Order.builder()
						.customerName(orderReq.getCustomerName())
						.orderDate(orderReq.getOrderDate())
						.productId(orderReq.getProductId())
						.build();
		
		log.debug("order = {}",order);
		//validate if the product is valid or not
		
		APIResponse resp = restTemplate.getForObject("http://localhost:8081/products/"+orderReq.getProductId(), APIResponse.class);
		
		if(resp.getHttpCode() == HttpStatus.NOT_FOUND.value() || resp.getStatus().equals("Error") ) {
			log.error("ProductId is invalud");
			throw new InvalidProductException("Product is invalid");
		}
			
				
		orderRepo.save(order);
		
		log.debug("order After saving = {}",order);
		
		return new ResponseEntity<>(order,HttpStatus.OK) ;
	}

}
