package com.photon.serviceorder.entities;


import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(name="orders")
@Data
@Builder
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="product_id")
	private Integer productId;
	
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="order_date")
	private Instant orderDate;
	
	

}
