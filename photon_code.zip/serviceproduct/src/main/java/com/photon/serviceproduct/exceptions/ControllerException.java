package com.photon.serviceproduct.exceptions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.photon.serviceproduct.dto.APIResponse;
import com.photon.serviceproduct.service.ProductService;

@RestControllerAdvice
public class ControllerException {

	public static Logger log =  LogManager.getLogger(ProductService.class);

	@ExceptionHandler(GeneralProductException.class)
	public ResponseEntity<APIResponse> handleException(Exception ex){
		
		
		APIResponse response = APIResponse.builder()
				.message("Some Error Occured please contact Administrator").httpCode(HttpStatus.NOT_FOUND.value())
				.status("Error").build();

			log.error("ControllerException::handleException:Exception Occured {}",ex.getMessage());
			
			return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	
	@ExceptionHandler(GeneralProductException.class)
	public ResponseEntity<APIResponse> handleProductNotFoundexcptionException(ProductNotFoundException ex){
		
		APIResponse response = APIResponse.builder()
				.message("Some Error Occured please contact Administrator").httpCode(HttpStatus.NOT_FOUND.value())
				.status("Error").build();

			log.error("ControllerException::handleProductNotFoundexcptionException:Product not found {}",ex.getMessage());
			
			return new ResponseEntity<>(response,HttpStatus.OK);

 
	}
}
