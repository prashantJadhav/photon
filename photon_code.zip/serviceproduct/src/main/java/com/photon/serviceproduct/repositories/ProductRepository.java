package com.photon.serviceproduct.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.photon.serviceproduct.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

}
