package com.photon.serviceproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceproductApplication.class, args);
	}

}
