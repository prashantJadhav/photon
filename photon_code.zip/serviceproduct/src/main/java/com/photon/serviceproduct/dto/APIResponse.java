package com.photon.serviceproduct.dto;

import java.util.Map;


import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@Builder
public class APIResponse {

	private String status;
	private Integer httpCode;
	private String message;
	private Map<String,Object> data;
}
