package com.photon.serviceproduct.service;

import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.photon.serviceproduct.dto.APIResponse;
import com.photon.serviceproduct.dto.ProductDTO;
import com.photon.serviceproduct.entities.Product;
import com.photon.serviceproduct.exceptions.ProductNotFoundException;
import com.photon.serviceproduct.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired 
	ProductRepository productRepo;
	
	public static Logger log =  LogManager.getLogger(ProductService.class);
	
	@Override
	public ResponseEntity<?> getProducts() {
		// TODO Auto-generated method stub
		
		log.trace("ProductServiceImpl::getProducts");
		
		List<Product> products = productRepo.findAll();
		
		APIResponse.builder().message("Product Data").httpCode(HttpStatus.OK.value()).status("Success").build();
		
		APIResponse response = APIResponse.builder()
								.message("Product Data").httpCode(HttpStatus.OK.value())
								.status("Success").build();
		
		log.debug("ProductServiceImpl::getProducts:count of products is {}",products.size());
		
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}

	@Override
	public ResponseEntity<?> getProductById(Long productId) {
		// TODO Auto-generated method stub
		
		log.trace("ProductServiceImpl::getProductById");
		log.debug("ProductServiceImpl::getProductById id={}",productId);
		
		
		Optional<Product> prd = productRepo.findById(productId);
		
		if(!prd.isPresent())
			throw new ProductNotFoundException("Product with provided id is not present");
		
		
		Product product = prd.get();
		
		ProductDTO prdDto = buildProductDTO(product);
		
		log.debug("ProductServiceImpl::getProductById: product={}",product);
		Map<String,Object> data= new HashMap<String,Object>(); 
		
		data.put("Products", prdDto);
		
		APIResponse response = APIResponse.builder()
				.httpCode(HttpStatus.OK.value())
				.message("Retrves product succesfully")
				.data(data)
				.build();
				
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	
	 private ProductDTO buildProductDTO(Product prd)
	 {
		
		 ProductDTO prdDto = ProductDTO.builder()
				 				.productId(prd.getId())
				 				.productDescription(prd.getDescription())
				 				.productName(prd.getName())
				 				.productPrice(prd.getPrice())
				 				.imageUrl(null)
				 				.build();
		 
		 
		 return prdDto;
	 }

}
