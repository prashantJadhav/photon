package com.photon.serviceproduct.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ProductDTO {

	private Long productId;
	private String productName;
	private String productDescription;
	private Integer productPrice;
	private String imageUrl;
}
