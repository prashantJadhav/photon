package com.photon.serviceproduct.service;

import org.springframework.http.ResponseEntity;

public interface ProductService {
	public ResponseEntity<?> getProducts();
	
	public ResponseEntity<?> getProductById(Long productId);
	
}
