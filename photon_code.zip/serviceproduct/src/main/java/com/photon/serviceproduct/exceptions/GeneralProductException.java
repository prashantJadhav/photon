package com.photon.serviceproduct.exceptions;

public class GeneralProductException extends RuntimeException {

	public GeneralProductException(String exceptionMsg){
		super(exceptionMsg);
		
	}
	
}
