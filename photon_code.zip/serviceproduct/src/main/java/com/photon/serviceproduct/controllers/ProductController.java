package com.photon.serviceproduct.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.photon.serviceproduct.repositories.ProductRepository;
import com.photon.serviceproduct.service.ProductService;

@RestController
@RequestMapping(value="/products")
public class ProductController {

	@Autowired
	ProductService productService;
	
	
	/**
	 *method to et all the products when get endpoint is called 
	 */
	@GetMapping
	public ResponseEntity<?> getAllProducts()
	{
		return productService.getProducts() ;
	}
	
	@GetMapping(value="/{id}")
	public ResponseEntity<?> getAllProducts(@PathVariable("id") Long id)
	{
		return productService.getProductById(id) ;
	}
	
	
}
